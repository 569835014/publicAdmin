//ajax请求成功
const API_SUCCESS_CODE=0;//请求成功
//ajax请求异常
const API_ABNORMAl_CODE='A0001';//异常：错误操作和不合法数据之类的，
//ajax请求错误
const API_ERROR_CODE="E0001";//程序出现错误
//登录失效
const API_LOGIN_OUT='100';//登录失效

export {API_SUCCESS_CODE,API_ABNORMAl_CODE,API_ERROR_CODE,API_LOGIN_OUT}
