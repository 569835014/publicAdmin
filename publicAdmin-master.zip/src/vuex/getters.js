
export const userInfo = state => {
  return state.userInfo
};
export const token = state => {
  return state.userInfo.token
};
export const activeMenu = state =>{
  return state.activeMenu
};
